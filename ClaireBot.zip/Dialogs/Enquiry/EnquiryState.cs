namespace HackedDesign.ClaireBot
{
    /// <summary>
    /// User state properties for Enquiry.
    /// </summary>
    public class EnquiryState
    {
        public string Name { get; set; }
        public string Topic { get; set; }
    }
}